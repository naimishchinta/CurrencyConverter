"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowRightLeft } from "lucide-react"

const CURRENCIES = [
  "USD",
  "EUR",
  "GBP",
  "JPY",
  "AUD",
  "CAD",
  "CHF",
  "CNY",
  "INR",
  "MXN",
  "BRL",
  "ZAR",
  "SGD",
  "HKD",
  "NZD",
  "KRW",
]

export default function CurrencyConverter() {
  const [amount, setAmount] = useState("1")
  const [fromCurrency, setFromCurrency] = useState("USD")
  const [toCurrency, setToCurrency] = useState("EUR")
  const [convertedAmount, setConvertedAmount] = useState("0")
  const [exchangeRate, setExchangeRate] = useState("0")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")

  useEffect(() => {
    const fetchExchangeRate = async () => {
      if (!amount || Number.parseFloat(amount) <= 0) {
        setConvertedAmount("0")
        setExchangeRate("0")
        return
      }

      setLoading(true)
      setError("")

      try {
        const response = await fetch(`https://api.exchangerate-api.com/v4/latest/${fromCurrency}`)

        if (!response.ok) throw new Error("Failed to fetch exchange rate")

        const data = await response.json()
        const rate = data.rates[toCurrency]

        if (!rate) throw new Error("Currency not found")

        setExchangeRate(rate.toFixed(4))
        setConvertedAmount((Number.parseFloat(amount) * rate).toFixed(2))
      } catch (err) {
        setError("Unable to fetch exchange rate. Please try again.")
        console.error(err)
      } finally {
        setLoading(false)
      }
    }

    fetchExchangeRate()
  }, [amount, fromCurrency, toCurrency])

  const handleSwap = () => {
    setFromCurrency(toCurrency)
    setToCurrency(fromCurrency)
  }

  return (
    <main className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-lg">
        <div className="p-8">
          <h1 className="text-3xl font-bold text-center text-gray-800 mb-2">Currency Converter</h1>
          <p className="text-center text-gray-600 mb-8">Convert between currencies instantly</p>

          {/* From Currency Section */}
          <div className="mb-6">
            <label className="block text-sm font-semibold text-gray-700 mb-2">From</label>
            <div className="flex gap-2">
              <select
                value={fromCurrency}
                onChange={(e) => setFromCurrency(e.target.value)}
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                {CURRENCIES.map((curr) => (
                  <option key={curr} value={curr}>
                    {curr}
                  </option>
                ))}
              </select>
              <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0"
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          {/* Swap Button */}
          <div className="flex justify-center mb-6">
            <Button onClick={handleSwap} variant="outline" size="icon" className="rounded-full bg-transparent">
              <ArrowRightLeft className="w-4 h-4" />
            </Button>
          </div>

          {/* To Currency Section */}
          <div className="mb-6">
            <label className="block text-sm font-semibold text-gray-700 mb-2">To</label>
            <div className="flex gap-2">
              <select
                value={toCurrency}
                onChange={(e) => setToCurrency(e.target.value)}
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                {CURRENCIES.map((curr) => (
                  <option key={curr} value={curr}>
                    {curr}
                  </option>
                ))}
              </select>
              <input
                type="text"
                value={loading ? "Loading..." : convertedAmount}
                readOnly
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg bg-gray-50 text-gray-700"
              />
            </div>
          </div>

          {/* Exchange Rate Display */}
          <div className="bg-blue-50 rounded-lg p-4 mb-6">
            <p className="text-sm text-gray-600 text-center">
              1 {fromCurrency} = {exchangeRate} {toCurrency}
            </p>
          </div>

          {/* Error Message */}
          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-3 mb-4">
              <p className="text-sm text-red-700">{error}</p>
            </div>
          )}

          {/* Info */}
          <p className="text-xs text-gray-500 text-center">Exchange rates updated in real-time</p>
        </div>
      </Card>
    </main>
  )
}
